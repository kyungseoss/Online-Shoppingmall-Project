$(document).ready(function(){
	$("#cancle").click(function(){//[취소]버튼 클릭
		window.location.href="/shoppingmall/index.do";
	});
});
